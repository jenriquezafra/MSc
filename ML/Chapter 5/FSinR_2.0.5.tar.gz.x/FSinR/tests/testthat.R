library(testthat)
library(FSinR)

test_check("FSinR")
